import { useState } from "react";

function AddTechnology({ addTechnology }) {
    const [title, setTitle] = useState()
    const [description, setDescription] = useState()

    const handleTitleChange = (event) => {
        setTitle(event.target.value);
    };

    const handleDescriptionChange = (event) => {
        setDescription(event.target.value);
    };

    const handleSubmit = async (event) => {
        event.preventDefault();

        await addTechnology({ 
            "title": title, 
            "description": description,  
            "status": "not-started",
            "notes": ""
        });

        alert("Успешно")
    }

    return (
        <div>
            <h1>Добавление технологий</h1>
            <form className="import-actions" onSubmit={handleSubmit}>
                <input
                    type="text"
                    placeholder="Название технологии"
                    name="title"
                    value={title}
                    onChange={handleTitleChange}
                    required
                />
                <input
                    type="text"
                    placeholder="Название технологии"
                    name="description"
                    value={description}
                    onChange={handleDescriptionChange}
                    required
                />
                <button
                    type="submit"
                    className="import-button"
                >
                    Добавить
                </button>
            </form>
        </div>
    );
}

export default AddTechnology;