function Home(){
    return(
        <div className="page">
            <div className="page__header">
                <h1>Главная</h1>
            </div>
        </div>
    );
}

export default Home;