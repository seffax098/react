function Home(){
    return(
        <div>
            <h1>Главная</h1>
        </div>
    );
}

export default Home;