function Statistics() {
    
}

export default Statistics;